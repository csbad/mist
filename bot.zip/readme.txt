Please read, this bot only takes a valid List Domain.
If the URL's dead or not the Joomla cms will be passed.

www.trenggalek6etar.id
best regards : Wong Galek - Kopi Rokok - Jatim4u